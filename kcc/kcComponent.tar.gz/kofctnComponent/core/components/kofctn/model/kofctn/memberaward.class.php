<?php
class memberAward extends xPDOSimpleObject {}