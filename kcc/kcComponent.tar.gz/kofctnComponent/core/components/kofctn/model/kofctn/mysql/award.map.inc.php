<?php
$xpdo_meta_map['award']= array (
  'package' => 'kofctn',
  'version' => '1.1',
  'table' => 'kofctn_award',
  'extends' => 'xPDOSimpleObject',
  'fields' => 
  array (
    'awardName' => NULL,
  ),
  'fieldMeta' => 
  array (
    'awardName' => 
    array (
      'dbtype' => 'varchar',
      'precision' => '255',
      'phptype' => 'string',
      'null' => false,
    ),
  ),
);
