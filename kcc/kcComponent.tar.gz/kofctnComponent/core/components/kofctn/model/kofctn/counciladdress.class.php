<?php
class councilAddress extends xPDOSimpleObject {}