<?php
class kofcuser extends xPDOSimpleObject {}