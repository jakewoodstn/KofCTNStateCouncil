<?php
require_once (dirname(dirname(__FILE__)) . '/kofcuser.class.php');
class kofcuser_mysql extends kofcuser {}