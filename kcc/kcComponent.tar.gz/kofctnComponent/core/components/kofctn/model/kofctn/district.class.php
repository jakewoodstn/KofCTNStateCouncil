<?php
class district extends xPDOSimpleObject {}