<?php
class councilMeeting extends xPDOSimpleObject {}