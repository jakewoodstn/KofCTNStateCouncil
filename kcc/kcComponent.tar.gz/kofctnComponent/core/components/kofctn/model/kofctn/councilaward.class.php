<?php
class councilAward extends xPDOSimpleObject {}