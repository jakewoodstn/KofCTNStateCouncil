<?php
$xpdo_meta_map['region']= array (
  'package' => 'kofctn',
  'version' => '1.1',
  'table' => 'kofctn_region',
  'extends' => 'xPDOSimpleObject',
  'fields' => 
  array (
    'regionName' => NULL,
  ),
  'fieldMeta' => 
  array (
    'regionName' => 
    array (
      'dbtype' => 'varchar',
      'precision' => '20',
      'phptype' => 'string',
      'null' => false,
    ),
  ),
);
