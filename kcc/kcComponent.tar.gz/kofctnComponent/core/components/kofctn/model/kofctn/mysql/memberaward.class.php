<?php
require_once (dirname(dirname(__FILE__)) . '/memberaward.class.php');
class memberAward_mysql extends memberAward {}