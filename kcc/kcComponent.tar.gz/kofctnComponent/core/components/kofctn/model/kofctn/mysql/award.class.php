<?php
require_once (dirname(dirname(__FILE__)) . '/award.class.php');
class award_mysql extends award {}