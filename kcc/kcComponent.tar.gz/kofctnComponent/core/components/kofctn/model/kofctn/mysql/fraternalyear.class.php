<?php
require_once (dirname(dirname(__FILE__)) . '/fraternalyear.class.php');
class fraternalYear_mysql extends fraternalYear {}