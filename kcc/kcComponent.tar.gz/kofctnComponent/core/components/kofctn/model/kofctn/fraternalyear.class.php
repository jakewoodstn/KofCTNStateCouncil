<?php
class fraternalYear extends xPDOSimpleObject {}