<?php
class phone extends xPDOSimpleObject {}