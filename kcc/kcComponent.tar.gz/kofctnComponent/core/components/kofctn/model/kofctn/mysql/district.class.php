<?php
require_once (dirname(dirname(__FILE__)) . '/district.class.php');
class district_mysql extends district {}