<?php
class council extends xPDOSimpleObject {}