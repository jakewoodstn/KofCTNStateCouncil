<?php
require_once (dirname(dirname(__FILE__)) . '/councilofficerassignment.class.php');
class councilOfficerAssignment_mysql extends councilOfficerAssignment {}