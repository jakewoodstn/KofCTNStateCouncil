<?php
require_once (dirname(dirname(__FILE__)) . '/councilmeeting.class.php');
class councilMeeting_mysql extends councilMeeting {}