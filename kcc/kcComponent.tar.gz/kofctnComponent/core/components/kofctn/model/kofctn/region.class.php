<?php
class region extends xPDOSimpleObject {}