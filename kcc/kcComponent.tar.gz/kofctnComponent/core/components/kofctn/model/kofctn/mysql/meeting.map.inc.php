<?php
$xpdo_meta_map['meeting']= array (
  'package' => 'kofctn',
  'version' => '1.1',
  'table' => 'kofctn_meeting',
  'extends' => 'xPDOSimpleObject',
  'fields' => 
  array (
    'meetingName' => NULL,
  ),
  'fieldMeta' => 
  array (
    'meetingName' => 
    array (
      'dbtype' => 'varchar',
      'precision' => '45',
      'phptype' => 'string',
      'null' => false,
    ),
  ),
);
