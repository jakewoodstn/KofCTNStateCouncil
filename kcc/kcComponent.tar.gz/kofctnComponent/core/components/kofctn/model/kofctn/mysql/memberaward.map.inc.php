<?php
$xpdo_meta_map['memberAward']= array (
  'package' => 'kofctn',
  'version' => '1.1',
  'table' => 'kofctn_memberAward',
  'extends' => 'xPDOSimpleObject',
  'fields' => 
  array (
    'memberId' => NULL,
    'fraternalYearId' => NULL,
    'awardId' => NULL,
  ),
  'fieldMeta' => 
  array (
    'memberId' => 
    array (
      'dbtype' => 'int',
      'precision' => '8',
      'phptype' => 'integer',
      'null' => false,
    ),
    'fraternalYearId' => 
    array (
      'dbtype' => 'int',
      'precision' => '8',
      'phptype' => 'integer',
      'null' => false,
    ),
    'awardId' => 
    array (
      'dbtype' => 'int',
      'precision' => '8',
      'phptype' => 'integer',
      'null' => false,
    ),
  ),
);
