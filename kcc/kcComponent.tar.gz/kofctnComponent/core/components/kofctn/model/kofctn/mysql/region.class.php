<?php
require_once (dirname(dirname(__FILE__)) . '/region.class.php');
class region_mysql extends region {}