<?php
require_once (dirname(dirname(__FILE__)) . '/memberaddress.class.php');
class memberAddress_mysql extends memberAddress {}