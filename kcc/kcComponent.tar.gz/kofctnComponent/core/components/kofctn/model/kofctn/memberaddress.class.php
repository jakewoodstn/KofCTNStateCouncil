<?php
class memberAddress extends xPDOSimpleObject {}