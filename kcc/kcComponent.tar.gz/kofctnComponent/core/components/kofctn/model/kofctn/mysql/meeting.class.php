<?php
require_once (dirname(dirname(__FILE__)) . '/meeting.class.php');
class meeting_mysql extends meeting {}