<?php
class councilOfficerAssignment extends xPDOSimpleObject {}