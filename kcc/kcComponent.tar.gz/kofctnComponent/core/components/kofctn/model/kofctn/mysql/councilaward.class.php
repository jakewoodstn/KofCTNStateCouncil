<?php
require_once (dirname(dirname(__FILE__)) . '/councilaward.class.php');
class councilAward_mysql extends councilAward {}