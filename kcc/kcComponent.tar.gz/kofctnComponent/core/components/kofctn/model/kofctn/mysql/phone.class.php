<?php
require_once (dirname(dirname(__FILE__)) . '/phone.class.php');
class phone_mysql extends phone {}