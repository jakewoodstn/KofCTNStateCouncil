<?php

$xpdo_meta_map = array (
  'xPDOSimpleObject' => 
  array (
    0 => 'kofcuser',
    1 => 'memberAddress',
    2 => 'phone',
    3 => 'council',
    4 => 'officerRole',
    5 => 'councilAddress',
    6 => 'award',
    7 => 'councilAward',
    8 => 'councilMeeting',
    9 => 'fraternalYear',
    10 => 'meeting',
    11 => 'memberAward',
    12 => 'district',
    13 => 'region',
    14 => 'councilOfficerAssignment',
  ),
);