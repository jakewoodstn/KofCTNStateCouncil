<?php
class officerRole extends xPDOSimpleObject {}