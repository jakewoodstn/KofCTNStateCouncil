<?php
$xpdo_meta_map['councilAward']= array (
  'package' => 'kofctn',
  'version' => '1.1',
  'table' => 'kofctn_councilAward',
  'extends' => 'xPDOSimpleObject',
  'fields' => 
  array (
    'councilId' => NULL,
    'fraternalYearId' => NULL,
    'awardId' => NULL,
  ),
  'fieldMeta' => 
  array (
    'councilId' => 
    array (
      'dbtype' => 'int',
      'precision' => '8',
      'phptype' => 'integer',
      'null' => false,
    ),
    'fraternalYearId' => 
    array (
      'dbtype' => 'int',
      'precision' => '8',
      'phptype' => 'integer',
      'null' => false,
    ),
    'awardId' => 
    array (
      'dbtype' => 'int',
      'precision' => '8',
      'phptype' => 'integer',
      'null' => false,
    ),
  ),
);
