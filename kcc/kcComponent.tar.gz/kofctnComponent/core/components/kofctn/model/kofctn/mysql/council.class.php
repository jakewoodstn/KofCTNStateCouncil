<?php
require_once (dirname(dirname(__FILE__)) . '/council.class.php');
class council_mysql extends council {}