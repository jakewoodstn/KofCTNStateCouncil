<?php
class meeting extends xPDOSimpleObject {}