<?php
require_once (dirname(dirname(__FILE__)) . '/counciladdress.class.php');
class councilAddress_mysql extends councilAddress {}