<?php
class award extends xPDOSimpleObject {}