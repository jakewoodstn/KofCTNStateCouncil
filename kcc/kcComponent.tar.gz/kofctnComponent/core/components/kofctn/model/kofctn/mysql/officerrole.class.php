<?php
require_once (dirname(dirname(__FILE__)) . '/officerrole.class.php');
class officerRole_mysql extends officerRole {}