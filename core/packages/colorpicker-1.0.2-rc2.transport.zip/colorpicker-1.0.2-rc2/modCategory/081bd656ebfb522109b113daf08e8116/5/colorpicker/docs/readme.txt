--------------------
ColorPicker
--------------------
Version: 1.0.2-rc2
Released: February 1, 2012
Since: May 12, 2011
Author: Benjamin Vauchel <contact@omycode.fr>

ColorPicker is a TV for MODx Revolution 2.x inspired by ColorPickerField ExtJS Plugin

Official Documentation: http://www.omycode.fr/modx-extras/colorpicker.html
Bugs and Feature Requests: https://github.com/omycode/colorpicker
Questions: http://forums.modx.com/thread/41009/revo-colorpicker-tv
