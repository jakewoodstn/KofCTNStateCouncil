<?php
class ChurchLocationType extends xPDOSimpleObject {}