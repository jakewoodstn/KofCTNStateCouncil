<?php
class ChurchLocations extends xPDOSimpleObject {}