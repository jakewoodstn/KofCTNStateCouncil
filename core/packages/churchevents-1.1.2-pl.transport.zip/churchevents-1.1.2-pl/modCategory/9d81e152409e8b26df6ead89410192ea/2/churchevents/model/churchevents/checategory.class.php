<?php
class chECategory extends xPDOSimpleObject {}