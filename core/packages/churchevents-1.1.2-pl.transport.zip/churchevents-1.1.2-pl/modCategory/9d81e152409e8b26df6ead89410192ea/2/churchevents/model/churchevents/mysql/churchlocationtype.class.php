<?php
require_once (dirname(dirname(__FILE__)) . '/churchlocationtype.class.php');
class ChurchLocationType_mysql extends ChurchLocationType {}