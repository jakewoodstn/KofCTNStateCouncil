<?php
class chCalendar extends xPDOSimpleObject {}