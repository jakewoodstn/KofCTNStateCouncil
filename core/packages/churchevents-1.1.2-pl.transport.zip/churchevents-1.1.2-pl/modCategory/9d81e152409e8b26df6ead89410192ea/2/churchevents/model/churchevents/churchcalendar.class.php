<?php
class ChurchCalendar extends xPDOSimpleObject {}