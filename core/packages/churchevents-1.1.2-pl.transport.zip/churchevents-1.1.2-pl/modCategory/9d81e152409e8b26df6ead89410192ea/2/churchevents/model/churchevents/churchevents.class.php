<?php
class ChurchEvents extends xPDOSimpleObject {}