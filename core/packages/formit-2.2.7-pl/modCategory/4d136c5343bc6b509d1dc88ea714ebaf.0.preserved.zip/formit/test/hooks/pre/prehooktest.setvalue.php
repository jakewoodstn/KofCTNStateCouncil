<?php
$hook->setValue('name','TestPreValue');
return true;