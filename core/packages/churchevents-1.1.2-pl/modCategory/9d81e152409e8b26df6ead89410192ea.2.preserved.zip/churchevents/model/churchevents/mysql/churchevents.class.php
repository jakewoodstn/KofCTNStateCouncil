<?php
require_once (dirname(dirname(__FILE__)) . '/churchevents.class.php');
class ChurchEvents_mysql extends ChurchEvents {}