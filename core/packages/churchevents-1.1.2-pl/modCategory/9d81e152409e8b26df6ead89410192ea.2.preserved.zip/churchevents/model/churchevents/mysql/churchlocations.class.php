<?php
require_once (dirname(dirname(__FILE__)) . '/churchlocations.class.php');
class ChurchLocations_mysql extends ChurchLocations {}