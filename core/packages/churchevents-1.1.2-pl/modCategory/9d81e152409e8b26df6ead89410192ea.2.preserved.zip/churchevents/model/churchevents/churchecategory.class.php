<?php
class ChurchEcategory extends xPDOSimpleObject {}