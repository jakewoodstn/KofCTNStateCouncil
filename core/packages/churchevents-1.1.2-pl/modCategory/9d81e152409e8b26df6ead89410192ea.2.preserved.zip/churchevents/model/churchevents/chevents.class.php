<?php
class chEvents extends xPDOSimpleObject {}