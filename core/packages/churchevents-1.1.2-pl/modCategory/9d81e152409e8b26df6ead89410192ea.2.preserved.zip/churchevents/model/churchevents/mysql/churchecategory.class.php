<?php
require_once (dirname(dirname(__FILE__)) . '/churchecategory.class.php');
class ChurchEcategory_mysql extends ChurchEcategory {}