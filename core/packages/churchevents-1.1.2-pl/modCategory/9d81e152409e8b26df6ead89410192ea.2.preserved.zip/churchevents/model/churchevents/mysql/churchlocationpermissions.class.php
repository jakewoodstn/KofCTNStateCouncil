<?php
require_once (dirname(dirname(__FILE__)) . '/churchlocationpermissions.class.php');
class ChurchLocationPermissions_mysql extends ChurchLocationPermissions {}