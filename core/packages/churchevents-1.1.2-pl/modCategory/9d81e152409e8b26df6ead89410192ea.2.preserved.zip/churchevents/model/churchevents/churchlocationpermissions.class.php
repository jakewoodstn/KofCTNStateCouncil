<?php
class ChurchLocationPermissions extends xPDOSimpleObject {}