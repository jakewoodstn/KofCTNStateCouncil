<?php
require_once (dirname(dirname(__FILE__)) . '/churcheventlocations.class.php');
class ChurchEventLocations_mysql extends ChurchEventLocations {}