<?php
class ChurchEventLocations extends xPDOSimpleObject {}