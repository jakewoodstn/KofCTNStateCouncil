<?php
require_once (dirname(dirname(__FILE__)) . '/churchcalendar.class.php');
class ChurchCalendar_mysql extends ChurchCalendar {}